#ifndef HASH_H
#define HASH_H 1

int hash(char* name, int n);

#endif

